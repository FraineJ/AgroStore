library my_prj.globals;

// Base
export 'package:agrostores/Data/Globals/Shared/Shared.dart';
export 'package:agrostores/Data/Globals/Shared/Colors.dart';
export 'package:agrostores/Data/Globals/Shared/Funciones.dart';
export 'package:agrostores/Data/Globals/Shared/Globals.dart';

// Exports adicionales

