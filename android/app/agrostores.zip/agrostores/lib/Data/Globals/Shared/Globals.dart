

// Textos
double texto,textoTitulo,texto22,texto21,texto20,texto19,texto18,texto17,texto16,texto15,texto14,texto13,texto12,texto11,texto10, textoIcono;

// Margenes
double margenLateral,margenMini,margen,margen1,margen2,margen3,margen4,margen5,margen6;

// Datos del telefono
double ancho;
double alto;
double altoStatusBar;
double circular = 10.0;