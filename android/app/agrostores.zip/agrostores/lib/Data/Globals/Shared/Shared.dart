

final Regular = "SFProDisplay-Regular";
final Black = "Roboto-Black";
final Light = "Roboto-Light";
final Bold = "Roboto-Bold";