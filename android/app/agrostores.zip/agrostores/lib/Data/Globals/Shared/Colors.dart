
import 'package:flutter/material.dart';

var colorPrimario = colorAmarillo;
var colorAmarilloOscuro = colorAmarillo;

var colorAmarillo = Color(0xFFFFC857);
var colorAzulOscuro = Color(0xFF00699B);
var colorAzul = Color(0xFF33A9C2);
var colorAzulClaro = Color(0xFF9FD6F0);
var colorRojoOscuro = Color(0xFFD34240);
var colorRojoClaro = Color(0xFFEC5853);

var colorNegro = Color(0xFF000000);
var colorBlanco = Color(0xFFFFFFFF);


var colorGris = Color(0xFFD1D1D1);
var colorGrisFondo = Color(0xFFF6F6F6);
var colorGrisSemi = Color(0xFFEFEFEF);
var colorGrisOscuro = Color(0xFF2C2C2C);

