import 'package:flutter/material.dart';

class Registrar extends StatelessWidget {
  const Registrar({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
