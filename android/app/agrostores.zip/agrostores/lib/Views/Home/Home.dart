import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class HomePages extends StatefulWidget {
  const HomePages({Key key}) : super(key: key);

  @override
  _HomePagesState createState() => _HomePagesState();
}

class _HomePagesState extends State<HomePages> {
  @override
  Widget build(BuildContext context) {
    List<int> list = [1,2,3,4,5];
    return Scaffold(
      appBar: AppBar(
        title: Text("Bienvenido")

        ,
      ),
      body: Column(
        children: [
          ListView(
            children: [
              SizedBox(
                height: 200.0,
                width: double.infinity,
                child: CarouselSlider(
                  options: CarouselOptions(),
                  items: list.map((item) => Container(
                    child: Center(
                        child: Text(item.toString())
                    ),
                    color: Colors.green,
                  )).toList(),

                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
